import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  constructor(public http: HttpClient) { }

  getData(obj:any){
    let url ='https://benepik.in/yorker/api/brandForm'

    let headers = new HttpHeaders().set('Authorization', 'IrAuCxwLhBO49H7iqAxLpJ6ZRfK47C0Ia2DHFFZn');

    headers.set('Accept', 'application/json');
    return this.http.post(url, obj, { headers});


  }

}

