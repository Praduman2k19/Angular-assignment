import { Component } from '@angular/core';
import { ApiService } from './services/api.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
// import { ToastrComponentlessModule, ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Angular-assignment';
  userForm:any
  formData:any;
  constructor(public apiService:ApiService){
  }
  ngOnInit(): void {
    this.submitForm()
  }
  appreciationSubmitted=false
  submitForm(){
    var obj = {
      "client_id": "CO40", "device": "1", "device_id": "browser", "app_version": "1", "user_id": "115", "admin_id": "115", "brand_id":"108","is_panel":"1"}

    this.apiService.getData(obj).subscribe(res=>{
      console.log(res);
      this.formData=res

    })
  }
  submitForm1(){
    this.appreciationSubmitted=true
    console.log(this.formData);

  }


}
